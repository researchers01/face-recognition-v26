import os
import tkinter as tk
from PIL import Image, ImageTk
from pathlib import Path

class ImageGridGUI:
    def __init__(self, master, folder_path):
        self.master = master
        self.folder_path = folder_path
        self.image_files = self.get_image_files()

        # Create a Canvas widget with scrollbars
        canvas = tk.Canvas(master)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Create horizontal scrollbar
        x_scrollbar = tk.Scrollbar(master, orient=tk.HORIZONTAL, command=canvas.xview)
        x_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)
        canvas.configure(xscrollcommand=x_scrollbar.set)

        # Create vertical scrollbar
        y_scrollbar = tk.Scrollbar(master, orient=tk.VERTICAL, command=canvas.yview)
        y_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.configure(yscrollcommand=y_scrollbar.set)

        # Create a frame inside the canvas for the grid layout
        self.frame = tk.Frame(canvas)
        canvas.create_window((0, 0), window=self.frame, anchor=tk.NW)

        # Create an entry widget and search button
        self.entry = tk.Entry(master, width=20)
        self.entry.pack(pady=5)
        search_button = tk.Button(master, text="Search", command=self.search_images)
        search_button.pack(pady=5)

        # Initialize grid layout
        self.update_grid()

        # Bind the canvas to the frame to enable scrolling
        self.frame.bind("<Configure>", lambda event, canvas=canvas: self.on_frame_configure(canvas))

    def update_grid(self):
        # Clear the current grid
        for widget in self.frame.winfo_children():
            widget.destroy()

        # Calculate the number of rows and columns for the grid
        num_images = len(self.image_files)
        max_images_displayed = 1000
        num_columns = 13
        num_images_to_display = min(num_images, max_images_displayed)
        num_rows = -(-num_images_to_display // num_columns)

        # Create a grid layout inside the frame
        for i, image_file in enumerate(self.image_files[:num_images_to_display]):
            row, col = divmod(i, num_columns)
            img_path = os.path.join(self.folder_path, image_file)
            img = Image.open(img_path)
            img.thumbnail((95, 95))
            img = ImageTk.PhotoImage(img)

            label = tk.Label(self.frame, image=img, text=image_file, compound=tk.TOP)
            label.grid(row=row, column=col, padx=5, pady=5)
            label.image = img

    def search_images(self):
        search_term = self.entry.get().lower()
        if search_term:
            # Filter image files based on the search term
            self.image_files = [file for file in self.image_files if search_term in file.lower()]
        else:
            # If search term is empty, show all images
            self.image_files = self.get_image_files()

        # Update the grid with the filtered images
        self.update_grid()

    def on_frame_configure(self, canvas):
        canvas.configure(scrollregion=canvas.bbox("all"))

    def get_image_files(self):
        files = os.listdir(self.folder_path)
        image_files = [file for file in files if file.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp'))]
        return image_files

def main():
    folder_path = r'data_img'

    root = tk.Tk()
    root.title("Image Grid GUI")
    root.state('zoomed')
    
    app = ImageGridGUI(root, folder_path)

    root.mainloop()

if __name__ == "__main__":
    main()
